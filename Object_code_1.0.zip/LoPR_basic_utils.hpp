/*** include file for clstrfns.cpp ***/

#ifndef _tp_basic_utils_H_
#define _tp_basic_utils_H_

#include <cstdio>                                     
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <fstream>
#include <ostream>

/** macros **/


/** types and classes**/


/** function prototypes **/
extern void LoPR_usage(int verbose);
     
#endif
