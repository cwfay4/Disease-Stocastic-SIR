#ifndef DiseasePOP_H
#define DiseasePOP_H

#include <cmath>

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "graph.hpp"
#include "random.hpp"
#include "diseasePOP.hpp"



class dPOP{
	public:
	   int n_immune;
	   int n_sick;
	   int n_healthy;
	   int n_dead;
	   double lifetime;
	   double p_Immune;
	   double p_sick;
	   double contagin;
	   double fatality;	
	   bool I;
	   dPOP (int, int, int, int, double, double, double, double);
	   dPOP ();
};


#endif
