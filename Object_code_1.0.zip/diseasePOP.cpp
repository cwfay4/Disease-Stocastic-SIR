#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "random.hpp"
#include "graph.hpp"
#include "diseasePOP.hpp"

using namespace std;


dPOP::dPOP () {
   n_immune =0;
   n_sick=0;
   n_healthy =0;
   n_dead =0;
   p_Immune =0;
   p_sick =0;
   contagin =0;
   fatality =0;
   I=false;
   lifetime=100;   
   return;
}
dPOP::dPOP (int a, int b, int c, int d, double e, double f, double g, double h) {  //I don't know if I am using this
   n_immune =a;
   n_sick=b;
   n_healthy =c;
   n_dead =d;
   p_Immune =e;
   p_sick =f;
   contagin =g;
   fatality =h;   
   lifetime=100; 
   I=false; 
   return;
}
