#ifndef RANDOM_H
#define RANDOM_H

#include <cmath>

using namespace std;

/***** Random Number Generators ***********************/

extern float ran0(long *idum);
extern float ran1(long *idum);
extern float ran2(long *idum);
extern float ran3(long *idum);

#endif
